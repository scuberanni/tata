from django.apps import AppConfig


class D2HManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'd2h_manager'
